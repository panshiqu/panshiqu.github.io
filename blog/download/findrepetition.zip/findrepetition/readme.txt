自己最真实的需求，从大学时期产生的各种文件一直被我存着，重复文件就再所难免。已经存在几款查找重复工具可以满足我的基本需求，但是我的个别需求却无法满足，不得不让我重新造轮子，现在将我实现的小工具分享给大家。

我认为具有如下优点 
* 跨平台（支持 Windows, Linux, Mac） 
* 可定制（若你会点编程可轻松扩展你的需求）

工具特性 
* 跳过 . 开头目录，但会打印出来这些路径 
* 跳过大小为 0 的文件 
* 打印后缀为 rar zip iso tar gz 的文件，主要是担心解压后会产生重复文件，提醒你关注一下 
* 通过比对文件内容 md5 值判定是否重复，坚信内容相同文件就相同 
* 多个相同文件一起打印，相同文件有序打印，整体有序打印，便于查看

备注 
####point#### 标识开始打印 . 开头目录 
####compress#### 标识开始打印后缀为 rar zip iso tar gz 的文件

使用（均在各系统命令行下执行，在工具执行完成后打开 output.txt 文件查看打印）

Windows
windows.exe -path=F:\panshiqu 1>output.txt 2>&1

Linux
./linux -path=/home/panshiqu > output.txt

Mac
./mac -path=/home/panshiqu > output.txt

提醒 
你可在分析打印后大致推测出那两个文件夹可能相同，这里推荐你使用 Beyond Compare 比对两个庞大的文件夹是否相同，记得取消对勾 Session => Session Settings => Comparison => Compare timestamps 用于不比对时间戳