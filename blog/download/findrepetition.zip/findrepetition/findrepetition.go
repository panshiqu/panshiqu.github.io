package main

import (
	"bytes"
	"crypto/md5"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

var kv map[string][]string

var point []string

var compress []string

var path = flag.String("path", "", "")

// FileList 文件列表
func FileList(path string) {
	if err := filepath.Walk(path, func(path string, info os.FileInfo, err error) error {
		if info == nil {
			fmt.Println("info", err)
			return err
		}

		if info.IsDir() {
			if strings.HasPrefix(info.Name(), ".") {
				point = append(point, path)
				return filepath.SkipDir
			}

			return nil
		}

		if info.Size() == 0 {
			return nil
		}

		lowerName := strings.ToLower(info.Name())
		if strings.HasSuffix(lowerName, ".rar") ||
			strings.HasSuffix(lowerName, ".zip") ||
			strings.HasSuffix(lowerName, ".iso") ||
			strings.HasSuffix(lowerName, ".tar") ||
			strings.HasSuffix(lowerName, ".gz") {
			compress = append(compress, path)
		}

		f, err := os.Open(path)
		if err != nil {
			fmt.Println("Open", err)
			return err
		}

		defer f.Close()

		md5hash := md5.New()
		if _, err := io.Copy(md5hash, f); err != nil {
			fmt.Println("Copy", err)
			return err
		}

		key := fmt.Sprintf("%x", md5hash.Sum(nil))

		kv[key] = append(kv[key], path)

		return nil
	}); err != nil {
		fmt.Println("FileList", err)
	}
}

// SortOne 一维排序
type SortOne []string

func (s SortOne) Len() int {
	return len(s)
}
func (s SortOne) Less(i, j int) bool {
	return bytes.Compare([]byte(s[i]), []byte(s[j])) < 0
}
func (s SortOne) Swap(i, j int) {
	s[i], s[j] = s[j], s[i]
}

// SortTwo 二维排序
type SortTwo [][]string

func (s SortTwo) Len() int {
	return len(s)
}
func (s SortTwo) Less(i, j int) bool {
	return bytes.Compare([]byte(s[i][0]), []byte(s[j][0])) < 0
}
func (s SortTwo) Swap(i, j int) {
	s[i], s[j] = s[j], s[i]
}

func main() {
	flag.Parse()

	kv = make(map[string][]string)

	FileList(*path)

	var tmp [][]string
	for _, v := range kv {
		if len(v) == 1 {
			continue
		}

		tmp = append(tmp, v)
	}

	for i := 0; i < len(tmp); i++ {
		sort.Sort(SortOne(tmp[i]))
	}

	sort.Sort(SortTwo(tmp))

	for _, v := range tmp {
		for _, vv := range v {
			fmt.Println(vv)
		}

		fmt.Println()
	}

	fmt.Println("####point####")
	for _, v := range point {
		fmt.Println(v)
	}

	fmt.Println("####compress####")
	for _, v := range compress {
		fmt.Println(v)
	}
}
